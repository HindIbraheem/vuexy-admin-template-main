<template>
  <div class="p-2 border-top text-danger cursor-pointer">
    <feather-icon icon="LogOutIcon" />
    <span class="ml-1">Logout</span>
  </div>
</template>
